import http.server
import socketserver
import os
import sys
import html
import socket
import datetime
import urllib.parse
import zipfile
import io
import threading
import ssl
import subprocess
import random
import base64
import shutil
import json
import platform
import tkinter
from tkinter import filedialog

# Favicon (64x64 Bs logo, transparent background PNG)
FAVICON_B64 = "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAKMWlDQ1BJQ0MgUHJvZmlsZQAAeJydlndUU9kWh8+9N71QkhCKlNBraFICSA29SJEuKjEJEErAkAAiNkRUcERRkaYIMijggKNDkbEiioUBUbHrBBlE1HFwFBuWSWStGd+8ee/Nm98f935rn73P3Wfvfda6AJD8gwXCTFgJgAyhWBTh58WIjYtnYAcBDPAAA2wA4HCzs0IW+EYCmQJ82IxsmRP4F726DiD5+yrTP4zBAP+flLlZIjEAUJiM5/L42VwZF8k4PVecJbdPyZi2NE3OMErOIlmCMlaTc/IsW3z2mWUPOfMyhDwZy3PO4mXw5Nwn4405Er6MkWAZF+cI+LkyviZjg3RJhkDGb+SxGXxONgAoktwu5nNTZGwtY5IoMoIt43kA4EjJX/DSL1jMzxPLD8XOzFouEiSniBkmXFOGjZMTi+HPz03ni8XMMA43jSPiMdiZGVkc4XIAZs/8WRR5bRmyIjvYODk4MG0tbb4o1H9d/JuS93aWXoR/7hlEH/jD9ld+mQ0AsKZltdn6h21pFQBd6wFQu/2HzWAvAIqyvnUOfXEeunxeUsTiLGcrq9zcXEsBn2spL+jv+p8Of0NffM9Svt3v5WF485M4knQxQ143bmZ6pkTEyM7icPkM5p+H+B8H/nUeFhH8JL6IL5RFRMumTCBMlrVbyBOIBZlChkD4n5r4D8P+pNm5lona+BHQllgCpSEaQH4eACgqESAJe2Qr0O99C8ZHA/nNi9GZmJ37z4L+fVe4TP7IFiR/jmNHRDK4ElHO7Jr8WgI0IABFQAPqQBvoAxPABLbAEbgAD+ADAkEoiARxYDHgghSQAUQgFxSAtaAYlIKtYCeoBnWgETSDNnAYdIFj4DQ4By6By2AE3AFSMA6egCnwCsxAEISFyBAVUod0IEPIHLKFWJAb5AMFQxFQHJQIJUNCSAIVQOugUqgcqobqoWboW+godBq6AA1Dt6BRaBL6FXoHIzAJpsFasBFsBbNgTzgIjoQXwcnwMjgfLoK3wJVwA3wQ7oRPw5fgEVgKP4GnEYAQETqiizARFsJGQpF4JAkRIauQEqQCaUDakB6kH7mKSJGnyFsUBkVFMVBMlAvKHxWF4qKWoVahNqOqUQdQnag+1FXUKGoK9RFNRmuizdHO6AB0LDoZnYsuRlegm9Ad6LPoEfQ4+hUGg6FjjDGOGH9MHCYVswKzGbMb0445hRnGjGGmsVisOtYc64oNxXKwYmwxtgp7EHsSewU7jn2DI+J0cLY4X1w8TogrxFXgWnAncFdwE7gZvBLeEO+MD8Xz8MvxZfhGfA9+CD+OnyEoE4wJroRIQiphLaGS0EY4S7hLeEEkEvWITsRwooC4hlhJPEQ8TxwlviVRSGYkNimBJCFtIe0nnSLdIr0gk8lGZA9yPFlM3kJuJp8h3ye/UaAqWCoEKPAUVivUKHQqXFF4pohXNFT0VFysmK9YoXhEcUjxqRJeyUiJrcRRWqVUo3RU6YbStDJV2UY5VDlDebNyi/IF5UcULMWI4kPhUYoo+yhnKGNUhKpPZVO51HXURupZ6jgNQzOmBdBSaaW0b2iDtCkVioqdSrRKnkqNynEVKR2hG9ED6On0Mvph+nX6O1UtVU9Vvuom1TbVK6qv1eaoeajx1UrU2tVG1N6pM9R91NPUt6l3qd/TQGmYaYRr5Grs0Tir8XQObY7LHO6ckjmH59zWhDXNNCM0V2ju0xzQnNbS1vLTytKq0jqj9VSbru2hnaq9Q/uE9qQOVcdNR6CzQ+ekzmOGCsOTkc6oZPQxpnQ1df11Jbr1uoO6M3rGelF6hXrtevf0Cfos/ST9Hfq9+lMGOgYhBgUGrQa3DfGGLMMUw12G/YavjYyNYow2GHUZPTJWMw4wzjduNb5rQjZxN1lm0mByzRRjyjJNM91tetkMNrM3SzGrMRsyh80dzAXmu82HLdAWThZCiwaLG0wS05OZw2xljlrSLYMtCy27LJ9ZGVjFW22z6rf6aG1vnW7daH3HhmITaFNo02Pzq62ZLde2xvbaXPJc37mr53bPfW5nbse322N3055qH2K/wb7X/oODo4PIoc1h0tHAMdGx1vEGi8YKY21mnXdCO3k5rXY65vTW2cFZ7HzY+RcXpkuaS4vLo3nG8/jzGueNueq5clzrXaVuDLdEt71uUnddd457g/sDD30PnkeTx4SnqWeq50HPZ17WXiKvDq/XbGf2SvYpb8Tbz7vEe9CH4hPlU+1z31fPN9m31XfKz95vhd8pf7R/kP82/xsBWgHcgOaAqUDHwJWBfUGkoAVB1UEPgs2CRcE9IXBIYMj2kLvzDecL53eFgtCA0O2h98KMw5aFfR+OCQ8Lrwl/GGETURDRv4C6YMmClgWvIr0iyyLvRJlESaJ6oxWjE6Kbo1/HeMeUx0hjrWJXxl6K04gTxHXHY+Oj45vipxf6LNy5cDzBPqE44foi40V5iy4s1licvvj4EsUlnCVHEtGJMYktie85oZwGzvTSgKW1S6e4bO4u7hOeB28Hb5Lvyi/nTyS5JpUnPUp2Td6ePJninlKR8lTAFlQLnqf6p9alvk4LTduf9ik9Jr09A5eRmHFUSBGmCfsytTPzMoezzLOKs6TLnJftXDYlChI1ZUPZi7K7xTTZz9SAxESyXjKa45ZTk/MmNzr3SJ5ynjBvYLnZ8k3LJ/J9879egVrBXdFboFuwtmB0pefK+lXQqqWrelfrry5aPb7Gb82BtYS1aWt/KLQuLC98uS5mXU+RVtGaorH1futbixWKRcU3NrhsqNuI2ijYOLhp7qaqTR9LeCUXS61LK0rfb+ZuvviVzVeVX33akrRlsMyhbM9WzFbh1uvb3LcdKFcuzy8f2x6yvXMHY0fJjpc7l+y8UGFXUbeLsEuyS1oZXNldZVC1tep9dUr1SI1XTXutZu2m2te7ebuv7PHY01anVVda926vYO/Ner/6zgajhop9mH05+x42Rjf2f836urlJo6m06cN+4X7pgYgDfc2Ozc0tmi1lrXCrpHXyYMLBy994f9Pdxmyrb6e3lx4ChySHHn+b+O31w0GHe4+wjrR9Z/hdbQe1o6QT6lzeOdWV0iXtjusePhp4tLfHpafje8vv9x/TPVZzXOV42QnCiaITn07mn5w+lXXq6enk02O9S3rvnIk9c60vvG/wbNDZ8+d8z53p9+w/ed71/LELzheOXmRd7LrkcKlzwH6g4wf7HzoGHQY7hxyHui87Xe4Znjd84or7ldNXva+euxZw7dLI/JHh61HXb95IuCG9ybv56Fb6ree3c27P3FlzF3235J7SvYr7mvcbfjT9sV3qID0+6j068GDBgztj3LEnP2X/9H686CH5YcWEzkTzI9tHxyZ9Jy8/Xvh4/EnWk5mnxT8r/1z7zOTZd794/DIwFTs1/lz0/NOvm1+ov9j/0u5l73TY9P1XGa9mXpe8UX9z4C3rbf+7mHcTM7nvse8rP5h+6PkY9PHup4xPn34D94Tz+6TMXDkAABVWSURBVHiczVt7kBxHef91z8w+bndv73SS7vS0kGSfLE4Y+SRbGIyQsbHDIxQFdoiBFCaPqlSRgoSQkL9SVCUFeQEBUkWREKdMQRwcFwV2mYcpGyOBZfnOdnz2STpf9Dy9T/fa2+fMdKe+r2d2Z2d3T4fAxC2NVjvT09Pf19/j9/16VuBVbHv3/rXdOzB1rdD2jVrIXUKI7VrrjYBYIQSygEgDEFrrihAoAJgRECch1LjSGHV89dzF7QMTT332s96rNUfx6x7w7rvvThTc7E22EO/RQu7TSm9Tvp9z3Rqq1SpqtSo814Pve9Bam0kICcuyYDs2EskkkokUnEQCliUXpZBHlFBPwvMf6UoUn3nooYdqr0kF3Hnnh9b4tr5XCvtDylc7XddFcbGAUqmIWrUK3/frAl9xUkKwQkgZmUwWmWwOiUQC0pIvKM/7lrK9b//k+w+efU0o4NY737dGKufjWuNj0HqguLiIxUKBVxoksBAs0NU0UhgdUgg4ySSy2RwyuRykFBekEPfD9b/6xBMPnfl/UcDw8LBjda37I0uIzwBifWFhAeVSEUopM6gMhGAnF+ZzifE096A+ppcWwXe+V5uBoCGlha5MFtnubup5Rgh8rlJY9fXR0a+7vzEF7HrTu4Ycx/6iVrg9NHMWnEcLBKAZCyNAXKB2Ld6/6Rqfj3zXGkJKZDIZZHPdkAJPer7/yWcOPPLiq66A3be886NCWv/k1dwVtOqe57LgoZUrlqO9ECRmJwU0d24zs8i5UCFaaQ6c3fke2I4zI4E/f/rA9+9/VRSwd+9eu+zmPq+gP1UpllAqFs2qycZAxlRJ/HCmsScE36lfuz5KqIbJR+6jc6y4+i2kSI6WJs5AoCuTQSabha/8L+jahc+Mjo66vzYF7Nlzd7qmC9+Q0vrdxYUFVKsVs+ICUJFVJTOXOtDIVbQwDtA4rEYtoEAxJaLUTvdqjUQygVy+FwLqQVWVvz86+mjpV1bAnj170lWdf0AI+YHC3Bw8z4OUZuGCuBQJXM2+uqxmTKdZGLFMV2mjBNtxkMvnIaV8tDdT++Djjz9evNLjl4z0vux9QEN+sFQowPd8I6EIjHipSQamHlXQb6KREizbxAUN/R3pXfrwUu4glxqspvOfrwvveoG6yCwBodoIFYvUbYFP/FTdlK6iT5tzhDmU56EwP0ff79Gy7++WklF0ujC0c999Qlr/XikWjfAy1rVDgKOmOERrSD4R6cQx0nQUS40Tn1lLVmh0MnGDrDF+j3GHVFcGQuiP/c/IT+5ftgLesGvvkK+s/V611uNWq40c9xpplC2oXTHgUmBMpQhFzgsh3vLiyOMvxbvIdn7vufiq8lSPW6u95oQ3zaTEMGt07iZMHeJ5eV/5/7J9+92JKyqg5Gb/AELurVVKMade3tSuOKlfQ5OEC5Soo8srTAjVSoU+3wrn0h/GL4vol6Ghm/tdJJ/Xylvj1dzG6td9N+K94Tn290ZGCPvxJ+OkWBxoM8HoTHSbk8FQDWPsMJ8WiSJxgeKB7TjnkNA3jj/71Pm2FuAK5xNCiDUm4kehWCyWUYSnVMhmSCsBaKmhLRpR8KhcAUoBLQUoYagOgTs6dig89wvGpLGUZcbmcYQ2QbY5lLbMMa4Mz3Vp6DWipj/RtsvQ0M39HhJjvuetIrKi06oR8mMXtAQXJKGg0UIoFCcESlQgsNLok4qFwHBEy7g0plGitFiLEJHsw/cqBeUHKVa1jrMUiCJ8IB3rctbBjtHR/efonB1erPryI9LCKiIuOglvsL+AtCWELSEdHhDCtowSWAeRCdMkSQG+gvJ8aM+Hcs0RKoPu4vkGQvN4jsVj0ydbFP1VgPZVMIYHVaPxSBmKxzGuFqszYo0W1rbtvlJNfxjAP9SXbPv27QkXPSNa6x0EIpZafRJWJm3Y6QSQsmFlkrBSDqRtNYiPAN7yqtMESeiaB1X1oCo1+OWa+e4ps4okfMIy46QTEEkHVlcCTiYJJ5MiWMtKqy6W4RUrUBUPmsYp1eDXXDOOT3VIiMWbsUf0KzFNwrJeVhuyw5M//GGVLcAT3buhxZCm1Q/NJxZMTMATbPq0SvlN/dj9sd+CTNvGFahAiLmkChRQKZQwc/I8zo8dx/ypS5CFMrzFCkTFNVZgWyywnUsjsSKLNTdsxqabr0fv+tVwsmmeNPlwaaaA6ckzOPXMYVw8fArCKUMsSlaor31oP1ZlxuWAhq884hq3y1OF3QAOsAKUL94rJLOz7Rc/qOVJAWT+MuUg1Z/H5r07YNmW8c1OLQiUBEpq80W89ONDGPvuAR7LI/P3FCRZUnca3VsGcMt978S6N24FKAYEvs4EiADyA31YN7QZ2+7YhZcfO4ixh3+Gmijw84mQ4X5tBQ81YjIWTUjBfy8rgIDP7KJ6u1xKiLowFPAsVgCtmFfzGgGOY6GxgiB58b9Kk5mTAAJOrgvDv/N2pDJpHPqPH/F58mcrk0L3pn7s+8QHsOq6Dewe8FxQ2UlxgVaVrIniiIIPK+lg5z37kOpK4plv/AB+zYNkppnmEpG9pdKkCKugFMU5+XaS3Z4uYIslMKiVgZftWwS/k4wUBxJOjLQAFmbnmfLm06QYAaSzXcjkMvBphdjFNLbfsRunn5vA6UNHYXk2ZCaJG377Fqy5biMq1SqPZVsWiguLuHDqPCskt7IHq9f3w6f0S0FVexi84yYcP3QYUz8f54ApKDAG/EF92lFTDD9JVoHBhYq91ZZCDgshM5q10tl3AoK3Tk5wugq5yoDKHvvpCC5MnIYu1uBXXFiOha7VeWx50w5sven1ZmJKQSYdrN25FWfHjrOZd/X3YO2N1xmugUCVFLh09hJGvvcU5k5egK56sDNJbL1lB95w1x5YQhhzTzrY8uYdOHPwaBCD2hRscVkCglZK0aWU2mVrhWESpq6sNlwcu02DkYqOFekmONpXzszCnSlBk1kmbNTmSzhcqWFg83r0rO41+wNKo3ugj6O+X/WRW7MC6XyGUxqPJCSOPXcYs8fOwZ8uwi+7cB2J8ZmD2LBtM1ZuWUv4Ho6vsWJ9Pyu/YcGxSBxvTcqQw7YAXk+0U8cWor2wTydkS4tbrUFRRF6ssAJ0gnK5hFuqolosAXIFtN9cyNLodtKGJWWjjmDfJaCjOd97JdpjUFBVH/u/9j2kerOmk+uhNL3AWYDT7TI3XhBmKKGHbAFxjcHanZl7g67aDxTCWxJIUI4lYTJJKAJLBGhSDpxcGkla4WCVCB7PnL7IAZAmTlZC8JvATwAgsHnnNpw/cgrzixVIcs+aAUAzE1McHGnFyc0UpdIAUxhAtFSLUsu84bLJ1lr3Ldkv6Nyw9wiiDyIuuR7T4V1JdG3og+qtwq96jBZza1fg+n3DyPXmWVhJwW2mgJPPHoEmQOP5mD9zGbNnp7F6yzpWBLlC3/rVeOtH34UTzx7GuZeOY/bERVQXihCugiZlVD2ADgp8nDUIKrbhTVpO1KlpOlbaQoi8udipYouYpTGHlr7G8jRuuO0m6L3DQe6mtCiQyqaRSicDPlGgUq7ghUcPYH5qmk0XFDcuF/DSY0/jbX/8PlaQojjhK/Ss6sWN734LqrftxvTUBVw4coqVcWliCnrOZBqyimAC9azXsfasB7K6FWRsQDfns5guGkO3aRHQSEcmn2mUsKFlKA3X8zlyl4tljPz4aZwbP2ZADq+kKbtP/nwcT+e6sPP9e9HVnTU531fwfQUrYXOKXLdtE6rvuAkXJ6dw5EeHcPLgYZ6hx3VFjZ9Vd9V2moihJK1h22ZzIbba9cIiWp/HKr2Ii4Sal7FUxLiJnJLytlJIdqVww9uGIUo1HD87xy6iy5qDHKW+o48dwvTxs9h2+y6sH9qMZD5rxiQM4fnwtMfIk64NbNuIFzb8DGMP72cITAoTpFSGw53WrHWhbWjQfnsLVRSI2XxjJFeGZWgdXgiByeePoDhbgAhWj9JZV08Wa7ZuQKavm8/lV/biTffcjup0ASdmxyDKkvM81QbkOpfHTuPgiUvIDvRg5eAGrNuxGf2vW4t0bzflbnYNDphSYNfd+1C8NIejjz0LWbFNpcmptJMTNJ8XEK4NrRYg5MpGhwa64fxa10ZL4R26Xv3Os4dPYOq5CaiFCqcsKpycXAq5jauw+/23of+aAV4pO53Ejve8mYujcsllM6dGAvilqgmMi1UsTF3G6YOHkV6Zw6ptG7H9bTeib32/iREUdS2B6+7YjRMHD0NTZVgmd6J02ChfmuWOnRAoUwyYARAoILgY3B1uSDXt1UU/owqhSpEi+FwZtelFTk8U0HTJxYLSOD56GP3XrDGCej76rhlA7+sGUJ1ZNOwSPSJhc4ok2CxrLo9XWajAnS2iPL2A2TMXseeD78BqUmTAMfSuW4nuNX2onp83JE3oj22jYVQB7PrTttI4ZUlc11jN8M5GMGMeoI3/RKMuEz+uMkQF1+sulOVDEalBkb5QMjggmKGdsNkt4FhYtWUTNu3ZzpQXB2pS2IGXMH/iguESKOcnHJQuzuPM4eNYvckoUgcsj51KQFuGmepg7S3NTEOdoDQ4DojbO9G+RhWx5Y5Q0o2CS5uyNm1Dd6egEhavppVLQqQd5AdWQFiSfZhZIAZ6isveno2rseveO+BxgQw4SLDQL8/OQ3hBYAuAVaIrZWAXv3lCpbwPr1oLsErzjDo3Dtk0xsu21hhpFbm5q/lPpPIJOL2GNoN4kLCRXNuLRK6LKziqGp1sEv2v34Tr3/zGYAxTVbmVKhYvzsOSFi6fOI+Fy7NIU/qj1ZYVDN4xjMLcAi6+cppjg9WVxKrB9XjdGwfriJIyxMKlORQvL5i0GpTmZLOi6RWVdgqgrXiM2Fr6I0qLkoDoQsfAEYOG9KAgcIXKoVV9AwGhW4fr5ATheyeZQLInY7C+bwanIun0c0eZHSIUVzg3g1PPHsHQXXtQrRhcn1uRx633vQsXTpxj98nks1ixoR920mmkOkti8sCLDKSYQwiLqSY52nHRtGCqJLUcsVd2y8nZBXVUCGtngxFqdSAOVAHRSWZnEFjD4Ohqvi9vTDOIGaquMENeEjK0EwnMnb+Mse/uR22uCFV22XVefuRp9G1ag1WDGwy2p/6OhXWDmwKobYojFp7yd9JhmDz5xPNQJZehMV8Ld6OXiAGmehQT+bz/ijRbx+LJpl2HiK3zn3pi0KxlIiI9qvcTNiyncVBNTkJS/mf6jA4pzPt/CQe+Vjjx/FE89ZWHMXP0DPxCBV6xyp8Lpy7hp199GMd/MWZq/YTDL0RxFUgmz+8FkQJtzhJjjx/CL/71UVQvLhiilMjRulU2paeACWoJ4k+Q7MwJWrb4nvLVnzZgXCPXMd2sKQ+YGECrL6oeqpcKOHZgDFYqwQGKI3C4ERB9ltKolqsoXZzDxYkpJjNrM0V4hTKzukyR16i601hUGj//2iOYGHweG4YH0bepH6nuLlau8jRKC4uYPXkBp0cncP7F43DnivAIcxDL7BoltXf6FjfW0lLfr0u6devWpC/yI1LYQ2EQMVoLqz7a3SG6STL9TUQGlbwU3e1ciilyKoUN99konswuueZU5lepbPWhyy5DXy5lA06RrYVo8XSCg52VNvQ4sUAOfbdJAT5qpQpcWu2yC1WqsfUQ3qDUy6uvFWGj5nf0eC6NeCVgkfwvS71ieHIyoMUnJyerm6/d9QAg/t4IH94dTSkBJCLcTf5G9TSRHiRQuCfQzu9C0jTYFOG8TpskbsS06aWGWsD1VT34RYtBkevYqPDGiGGVmf3lTRHPxAk33Bwh3zexoX1hZ8hQ4/8s0QOTr/yw2rQzlHLENys19RdCyJWG/YkAooAL5HigSQDilWnDw4NfDrbHlgIe/EqbISzM9pZBfnUEwQrSppghgWqCI7zZeotYbrA7xMVRfXssyCxNfGBQD7QohFHmtG+rbzbpJ2xbrt31OSGdzyjltSBCaiYS1AuFBlaMpMxGIokXUOFeYcOiDOEd7WYwZx3PxhXbxMU0dp9bkUs07Rl3oEXloKr8z//vKyN/1Xw1aElH/LNS/jkDIlqXlB5mURygydPD+SBrMBZBK8irQ0GTV5z+Ty9JEx2uYBE24DHMEY/VdIaYQakJpIRjmoMYHyY+g2v0XOobJNtIM4oOwnY9MHJaVv55x9JfbpYp0sbHnz0vhfobs8cXtb1mpYbv8DV4A/N+MN1GxAcrKFRSgMnCzcsWRqlp7EbQbe5F/F0jmfGhGyMba4hUscHzGh4QWBP03x45Msq7wmGTiLWEXfo3pbyfcS7nFt+DDuJD/Xu4bmYtjPcFf2i/ra6Cevfm1iQp8fMhqRJhlgLRm+qSOtwLDp5jO3bb0OxQan/aKX89flW0uQObt+0aEkru11r3NOfVuG81c0ZhfGh9KyR6X/xauxb349DSwqo0Dm0bUT4ulqlT9DykuvXY0dGx+JNku8cfOzLyklbqz4wVRAvszreFZkcRolmIuCAhzoi+MxL+v53wjXOhGlpb+/7heSnEp9oJT60jjX5scuR+aPVF3nJqadEJ/zKt00Sj137VcaOrT1FffXly4tA3Ot0plxq2p1v9pfbVf0kaqAVTt1upxmTaXl1CtjANtjtPGLSxcbO8l7HZerX672Si9Okl++EKbf36PelURv+nhnhvY/9tKTOsk2j8bz36X6HxO0L1ANo6ciMkdnp+o3G+h/5BwkrfMz7+1OKSfXGFNjV1sJzPevdC+w8KHjicSCxVNk3QCLFc4c1EOr8SH02HbQiLpp608kr531mO8FiuPY2OjpZ6cur3tPK/IJp+BNVuQu0JiOW0xu8C2in1SuMF89L6Symn9JHlCE9t+UsUtK2DN9+nlP5HIcQKRnjRYZoq0faBqb35xouuTv3aN1p1rfWsFOLTSwW8tvfiKtrmweEdQskvQYjb6HtrGb6UFcSrzPi1+D2dFREiVq31k7aQn5yYeOaX/tGUxFU0yqk93eouQH1caz3FiK9OSXeacJyoMDC2GVBdyfTDS+YlTQ09BeDjKad419UIf9UWEG0btw2vSWj7T7TCfRBiwFSEnUAQ2lSZ0fwfV4DqsOLqvJTW/bbwvhLH9r9xBYRtcHDnWk9Z90JYH9Za32AmG9b9YbsSXRUV2hhnneQwb6K9ILT6li39bx89+vxr46ez8Ub0GtCzR0nxbqGxT0MMBr8U5+tRIqRdJonyGlqhCIGjEOJJqdQjiUTp6fHx8dfmj6fRptF7ePPz1rWQ6kYNsUtrfb2AvEabvcg0oM02D1QFEGUBXAZwSguMC61HoORoT4+aWO5vAK+m/R8dt5sDG134uwAAAABJRU5ErkJggg=="

# Globals
AUTH_PIN = str(random.randint(1000000000, 9999999999))
SHARED_CLIPBOARD = ""
MOBILE_CONNECTED = False
SESSION_LOGGING = False  # Opt-in via landing page

PORT = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 8000
USE_HTTPS = 'https' in [a.lower() for a in sys.argv]
IS_ANDROID = os.environ.get('TERMUX_VERSION') is not None or os.path.isdir('/sdcard')
IS_IPAD = platform.system() == "Darwin" and (platform.machine().startswith('iPad') or 'iPad' in os.uname().version)

def notify_user(msg, title="BOCKshare"):
    if platform.system() == "Darwin":
        try: subprocess.run(['osascript', '-e', f'display notification "{msg}" with title "{title}"'], check=False)
        except: pass
    else:
        print(f"🔔 {title}: {msg}")

def select_folder():
    if platform.system() == "Darwin" and not IS_IPAD:
        res = subprocess.run(["osascript", "-e", 'POSIX path of (choose folder with prompt "Select folder (Virtual Root):")'], capture_output=True, text=True)
        return res.stdout.strip() if res.stdout else None
    elif IS_ANDROID or IS_IPAD:
        label = "iPadOS" if IS_IPAD else "Android"
        print(f"\x1b[1;36m BOCKshare for {label} \x1b[0m")
        # iPad (a-Shell) usually starts in documents or /private/var/mobile/Containers/Data/Application/.../Documents
        default_path = os.getcwd()
        path = input(f"📁 Enter path to share [Default: {default_path}]: ").strip()
        return path if path else default_path
    elif platform.system() == "Windows":
        try:
            root = tkinter.Tk()
            root.withdraw()
            root.attributes('-topmost', True)
            folder = filedialog.askdirectory(title="Select folder (Virtual Root)")
            root.destroy()
            return folder if folder else None
        except:
            return input("📁 Enter absolute path to share: ").strip()

def open_url(url):
    if platform.system() == "Darwin" and not IS_IPAD:
        subprocess.run(['/usr/bin/open', url], check=False, capture_output=True)
    elif IS_ANDROID:
        # Try termux-api if installed
        try: subprocess.run(['termux-open-url', url], check=False, capture_output=True)
        except: print(f"\n📱 Please open this link on your phone:\n\x1b[4;34m{url}\x1b[0m\n")
    elif platform.system() == "Windows":
        os.startfile(url)
    else:
        import webbrowser
        webbrowser.open(url)

def debug_log(msg):
    if not SESSION_LOGGING:
        return
    try:
        log_name = 'BOCKshare_session.log'
        log_path = os.path.join(os.getcwd(), log_name)
        with open(log_path, 'a') as f:
            f.write(f"[{datetime.datetime.now().isoformat()}] {msg}\n")
    except: pass

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('10.255.255.255', 1))
        return s.getsockname()[0]
    except:
        return '127.0.0.1'
    finally:
        s.close()

def gen_cert(ip_address):
    cert_path, conf_path = "/tmp/local_serve.pem", "/tmp/openssl_san.cnf"
    with open(conf_path, 'w') as f:
        f.write(f"[req]\ndistinguished_name=req_distinguished_name\nx509_extensions=v3_req\nprompt=no\n[req_distinguished_name]\nCN={ip_address}\n[v3_req]\nsubjectAltName=@alt_names\n[alt_names]\nIP.1={ip_address}\nDNS.1=localhost\nDNS.2={ip_address}\n")
    try:
        subprocess.run(["openssl", "req", "-new", "-newkey", "rsa:2048", "-days", "30", "-nodes", "-x509", "-config", conf_path, "-keyout", cert_path, "-out", cert_path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        return cert_path
    except: return None


class EnhancedHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):

    def send_json(self, data, status=200):
        body = json.dumps(data).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def check_auth(self):
        auth_header = self.headers.get('Authorization')
        if auth_header and auth_header.startswith('Basic '):
            try:
                decoded = base64.b64decode(auth_header[6:]).decode('utf-8')
                if ':' in decoded:
                    user, pwd = decoded.split(':', 1)
                    if pwd == AUTH_PIN:
                        return True
            except: pass
            
        cookie_header = self.headers.get('Cookie', '')
        if f"bockpin={AUTH_PIN}" in cookie_header:
            return True

        host = self.headers.get('Host', '')
        route = self.path.split('?')[0]

        # Allow __login__ from ANY device (that's the whole point of QR auto-login)
        if route == '/__login__':
            return True

        # Allow local preview/landing to poll without auth
        if ('localhost' in host or '127.0.0.1' in host) and route in ['/__landing__', '/api/check_mobile', '/api/clipboard', '/api/stats', '/api/search']:
            return True
            
        self.send_response(401)
        self.send_header('WWW-Authenticate', 'Basic realm="BOCKshare PIN"')
        self.end_headers()
        self.wfile.write(b"Unauthorized")
        return False

    def do_GET(self):
        global MOBILE_CONNECTED
        if not self.check_auth(): return
        
        host = self.headers.get('Host', '')
        if 'localhost' not in host and '127.0.0.1' not in host:
            MOBILE_CONNECTED = True

        route = self.path.split('?')[0]
        
        if route == '/__login__':
            params = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            pin = params.get('pin', [''])[0]
            if pin == AUTH_PIN:
                if params.get('debug', [''])[0] == '1':
                    global SESSION_LOGGING
                    SESSION_LOGGING = True
                    debug_log("Session Logging Enabled via Login.")
                
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Set-Cookie', f'bockpin={AUTH_PIN}; Path=/; Max-Age=31536000')
                self.end_headers()
                
                html = f"""<!DOCTYPE html>
                <html><head><meta charset="utf-8"><title>Login</title>
                <script>
                document.cookie = "bockpin={AUTH_PIN}; Path=/; max-age=31536000;";
                let n = new URLSearchParams(window.location.search).get('next') || '/';
                window.location.replace(n);
                </script></head><body>Redirecting securely...</body></html>"""
                self.wfile.write(html.encode('utf-8'))
            else:
                self.send_error(401, "Invalid Auto-Login PIN")
            return

        if route == '/favicon.ico':
            try:
                icon_data = base64.b64decode(FAVICON_B64)
                self.send_response(200)
                self.send_header('Content-Type', 'image/png')
                self.send_header('Content-Length', str(len(icon_data)))
                self.send_header('Cache-Control', 'public, max-age=604800')
                self.end_headers()
                self.wfile.write(icon_data)
            except:
                self.send_error(404)
            return

        if route == '/api/list':
            pwd = urllib.parse.unquote(self.path.split('pwd=')[-1]) if 'pwd=' in self.path else '/'
            base_dir = self.translate_path(pwd)
            if not os.path.abspath(base_dir).startswith(os.getcwd()):
                self.send_json({"error": "Access denied"}, 403)
                return
            self.send_json({"files": self.get_dir_contents(base_dir)})
            return

        if route == '/api/check_mobile':
            self.send_json({"status": "OK" if MOBILE_CONNECTED else "WAIT"})
            return
            
        if route == '/api/clipboard':
            self.send_json({"text": SHARED_CLIPBOARD})
            return

        if route == '/api/stats':
            try:
                st = os.statvfs('/')
                total = st.f_blocks * st.f_frsize
                free = st.f_bavail * st.f_frsize
                used_pct = (st.f_blocks - st.f_bfree) / st.f_blocks * 100
                self.send_json({
                    "used_pct": round(used_pct, 1),
                    "free_gb": round(free / (1024**3), 1),
                    "total_gb": round(total / (1024**3), 1)
                })
            except: self.send_json({"error": "Stats failed"}, 500)
            return

        if route == '/api/search':
            parsed = urllib.parse.urlparse(self.path)
            qs = urllib.parse.parse_qs(parsed.query)
            query = qs.get('q', [''])[0].lower()
            recursive = qs.get('recursive', ['false'])[0].lower() == 'true'
            
            results = []
            root_dir = os.getcwd()
            
            if recursive:
                for root, dirs, files in os.walk(root_dir):
                    for name in dirs + files:
                        if name.startswith('.'): continue
                        if query in name.lower():
                            rel_path = os.path.relpath(os.path.join(root, name), root_dir)
                            results.append(self.get_item_info(root, name, prefix=rel_path))
            else:
                for name in os.listdir(root_dir):
                    if query in name.lower() and not name.startswith('.'):
                        results.append(self.get_item_info(root_dir, name))
            
            self.send_json({"results": results[:200]})
            return

        if route == '/__landing__':
            self.serve_landing()
            return

        super().do_GET()

    def do_POST(self):
        if not self.check_auth(): return
        
        content_length = int(self.headers.get('Content-Length', 0))
        route = self.path.split('?')[0]
        
        if route == '/api/upload':
            file_name = urllib.parse.unquote(self.headers.get('X-File-Name', 'unnamed'))
            pwd_url = urllib.parse.unquote(self.headers.get('X-Pwd', '/'))
            
            base_dir = os.path.abspath(self.translate_path(pwd_url))
            target = os.path.abspath(os.path.join(base_dir, file_name))
            server_root = os.path.abspath(os.getcwd())
            if not target.startswith(server_root):
                self.send_json({"error": "Path traversal denied"}, 403)
                return

            os.makedirs(os.path.dirname(target), exist_ok=True)
            with open(target, 'wb') as f:
                bytes_left = content_length
                while bytes_left > 0:
                    chunk = self.rfile.read(min(65536, bytes_left))
                    if not chunk: break
                    f.write(chunk)
                    bytes_left -= len(chunk)
            
            self.send_json({"status": "ok"})
            return

        if route == '/api/zip_download':
            # Handle form encoded file arrays securely mapped back to correct directory
            data = self.rfile.read(content_length).decode('utf-8')
            params = urllib.parse.parse_qs(data)
            pwd = urllib.parse.unquote(params.get('pwd', ['/'])[0])
            files = params.get('files', [])
            
            if not files:
                self.send_error(400, "No files selected")
                return
                
            base_dir = os.path.abspath(self.translate_path(pwd))
            server_root = os.path.abspath(os.getcwd())
            if not base_dir.startswith(server_root):
                self.send_error(403, "Access denied")
                return
                
            self.send_response(200)
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Disposition', f'attachment; filename="bockshare_{datetime.datetime.now().strftime("%H%M")}.zip"')
            self.end_headers()
            
            zip_buffer = io.BytesIO()
            with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for f_encoded in files:
                    f = urllib.parse.unquote(f_encoded)
                    filepath = os.path.abspath(os.path.join(base_dir, f))
                    if not filepath.startswith(server_root): continue
                    
                    if os.path.isfile(filepath): 
                        zipf.write(filepath, arcname=f)
                    elif os.path.isdir(filepath):
                        for root, _, dirfiles in os.walk(filepath):
                            for name in dirfiles:
                                full_path = os.path.join(root, name)
                                rel_path = os.path.relpath(full_path, base_dir)
                                zipf.write(full_path, arcname=rel_path)
            self.wfile.write(zip_buffer.getvalue())
            return

        # Handle all pure JSON API calls
        raw_body = self.rfile.read(content_length)
        if not raw_body: self.send_json({"error": "Empty body"}, 400); return
            
        try: req = json.loads(raw_body.decode('utf-8'))
        except: self.send_json({"error": "Invalid JSON"}, 400); return
            
        try:
            if route == '/api/shutdown':
                self.send_json({"status": "ok"})
                threading.Thread(target=lambda: os._exit(0)).start()
                
            elif route == '/api/notify':
                count = req.get('count', 1)
                notify_mac(f"{count} file(s) uploaded successfully!")
                self.send_json({"status": "ok"})
                
            elif route == '/api/clipboard':
                global SHARED_CLIPBOARD
                SHARED_CLIPBOARD = req.get('text', '')
                self.send_json({"status": "ok"})
                
            elif route == '/api/mkdir':
                pwd = req.get('pwd', '/')
                target = req.get('target', '')
                if not target: raise ValueError("No folder name provided")
                base_dir = os.path.abspath(self.translate_path(pwd))
                full_path = os.path.abspath(os.path.join(base_dir, target))
                if not full_path.startswith(os.path.abspath(os.getcwd())): raise ValueError("Path traversal denied")
                
                os.makedirs(full_path, exist_ok=True)
                self.send_json({"status": "ok", "files": self.get_dir_contents(base_dir)})
                
            elif route == '/api/rename':
                pwd = req.get('pwd', '/')
                old_tgt = req.get('old', '')
                new_tgt = req.get('new', '')
                if not old_tgt or not new_tgt: raise ValueError("Old or new filename missing")
                
                base_dir = os.path.abspath(self.translate_path(pwd))
                old_full = os.path.abspath(os.path.join(base_dir, old_tgt))
                new_full = os.path.abspath(os.path.join(base_dir, new_tgt))
                server_root = os.path.abspath(os.getcwd())
                
                if not old_full.startswith(server_root) or not new_full.startswith(server_root): raise ValueError("Path traversal denied")
                    
                if os.path.exists(old_full):
                    os.rename(old_full, new_full)
                    self.send_json({"status": "ok", "files": self.get_dir_contents(base_dir)})
                else: raise FileNotFoundError(f"Source file '{old_tgt}' no longer exists.")
                    
            elif route == '/api/delete':
                pwd = req.get('pwd', '/')
                targets = req.get('targets', [])
                base_dir = os.path.abspath(self.translate_path(pwd))
                server_root = os.path.abspath(os.getcwd())
                deleted = 0
                for t in targets:
                    full_p = os.path.abspath(os.path.join(base_dir, t))
                    if full_p.startswith(server_root) and os.path.exists(full_p):
                        if os.path.isdir(full_p): shutil.rmtree(full_p)
                        else: os.remove(full_p)
                        deleted += 1
                self.send_json({"status": "ok", "deleted": deleted, "files": self.get_dir_contents(base_dir)})
                
            else:
                self.send_json({"error": "Unknown API route"}, 404)
        except Exception as e:
            self.send_json({"error": str(e)}, 500)


    def format_size(self, size):
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0: return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} TB"

    def get_item_info(self, base, name, prefix=None):
        full = os.path.join(base, name)
        is_dir = os.path.isdir(full)
        try:
            st = os.stat(full)
            return {
                "name": name,
                "path": prefix if prefix else name,
                "size": self.format_size(st.st_size) if not is_dir else "-",
                "mtime": datetime.datetime.fromtimestamp(st.st_mtime).strftime('%Y-%m-%d %H:%M'),
                "is_dir": is_dir
            }
        except: return {"name": name, "path": name, "size": "-", "mtime": "-", "is_dir": is_dir}

    def get_dir_contents(self, path):
        items = []
        try:
            for name in sorted(os.listdir(path), key=lambda x: x.lower()):
                if not name.startswith('.'):
                    items.append(self.get_item_info(path, name))
        except: pass
        return items

    def list_directory(self, path):
        try: list_dir = os.listdir(path)
        except OSError:
            self.send_error(404, "Permission denied.")
            return None
        list_dir.sort(key=lambda a: a.lower())
        
        displaypath = urllib.parse.unquote(self.path)
        parts = [p for p in displaypath.split('/') if p]
        breadcrumb = "<a href='/'>Home</a>"
        curr = "/"
        for p in parts:
            curr += urllib.parse.quote(p) + "/"
            breadcrumb += f" <span>/</span> <a href='{curr}'>{html.escape(p)}</a>"
            
        r = []
        r.append("<!DOCTYPE html><html lang='en' data-theme='dark'><head>")
        r.append(f"<title>BOCKshare - {html.escape(displaypath)}</title><meta charset='utf-8'>")
        r.append("<meta name='viewport' content='width=device-width, initial-scale=1.0'>")
        r.append("<link rel='icon' type='image/png' href='/favicon.ico'>")
        r.append("<style>")
        r.append("""
            /* Catppuccin Mocha - Dark */
            :root[data-theme='dark'] {
                --bg:#1e1e2e; --mantle:#181825; --surface:#313244; --surface1:#45475a; --surface2:#585b70;
                --text:#cdd6f4; --subtext:#a6adc8; --overlay:#6c7086;
                --accent:#94e2d5; --blue:#89b4fa; --lavender:#b4befe; --mauve:#cba6f7;
                --red:#f38ba8; --peach:#fab387; --green:#a6e3a1; --yellow:#f9e2af;
                --modal-bg:rgba(17,17,27,0.92);
            }
            /* Catppuccin Latte - Colorful Light */
            :root[data-theme='light'] {
                --bg:#dce0e8; --mantle:#eff1f5; --surface:#e6edef; --surface1:#ccd5da; --surface2:#bcc6cc;
                --text:#4c4f69; --subtext:#5c5f77; --overlay:#7c7f93;
                --accent:#179299; --blue:#1e66f5; --lavender:#7287fd; --mauve:#8839ef;
                --red:#d20f39; --peach:#fe640b; --green:#40a02b; --yellow:#df8e1d;
                --modal-bg:rgba(220,224,232,0.95);
            }
            * { box-sizing: border-box; margin: 0; }
            body { font-family: -apple-system, BlinkMacSystemFont, 'Inter', 'Segoe UI', sans-serif; padding: 12px; background: var(--bg); color: var(--text); transition: background 0.25s, color 0.25s; line-height: 1.5; -webkit-font-smoothing: antialiased; }

            .container { max-width: 960px; margin: 0 auto; background: var(--surface); padding: 20px; border-radius: 14px; box-shadow: 0 4px 24px rgba(0,0,0,0.25); }

            /* Header & Toolbar Alignment */
            .sys-controls, .toolbar-actions { display: flex; gap: 8px; align-items: center; margin-left: auto; }
            .header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 14px; margin-bottom: 20px; border-bottom: 1px solid var(--surface1); gap: 15px; }

            /* Buttons — consistent pill shape, modern icons */
            .btn { background: var(--accent); color: var(--bg); border: none; padding: 8px 16px; border-radius: 10px; cursor: pointer; font-weight: 600; font-size: 13px; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); white-space: nowrap; letter-spacing: 0.01em; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
            .btn svg { width: 16px; height: 16px; transition: transform 0.2s; }
            .btn:hover { filter: brightness(1.1); transform: translateY(-1px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
            .btn:hover svg { transform: scale(1.1); }
            .btn-ghost { background: var(--mantle); color: var(--subtext); border: 1px solid var(--surface1); }
            .btn-ghost:hover { background: var(--surface1); color: var(--text); border-color: var(--overlay); filter: none; }
            .btn-danger { color: var(--red); border-color: var(--red); }
            .btn-danger:hover { background: var(--red); color: var(--bg); }
            .btn-sm { padding: 6px 12px; font-size: 12px; border-radius: 8px; }
            .btn-icon-only { padding: 8px; aspect-ratio: 1/1; justify-content: center; }

            /* Modern Layout Row Spacing */
            .layout-row { margin-bottom: 24px; }
            .action-toolbar { display: flex; gap: 12px; align-items: center; justify-content: space-between; margin-top: 16px; padding: 12px; background: var(--mantle); border-radius: 12px; border: 1px solid var(--surface1); }
            
            .brand-logo { display: flex; align-items: center; justify-content: center; }
            .root-logo-img { height: 42px; width: 42px; border-radius: 50%; box-shadow: 0 0 20px rgba(148, 226, 213, 0.4); transition: all 0.2s ease; cursor: pointer; }
            .root-logo-img:hover { transform: scale(1.05); box-shadow: 0 0 25px rgba(148, 226, 213, 0.6); }
            
            .breadcrumb { display: flex; align-items: center; gap: 8px; margin-bottom: 20px; flex-wrap: wrap; }
            .breadcrumb h2 { margin: 0; }
            .breadcrumb a { color: var(--blue) !important; font-weight: 700; text-decoration: none; }
            .breadcrumb a:hover { color: var(--accent) !important; }
            .breadcrumb span { color: var(--subtext); padding: 0 4px; }
            .theme-btn-fixed { width: 42px !important; height: 42px !important; padding: 0 !important; display: flex !important; align-items: center; justify-content: center; }

            /* Toolbar */
            .toolbar { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; margin-bottom: 24px; padding: 16px; background: var(--mantle); border-radius: 12px; border: 1px solid var(--surface1); }
            .search-wrap { display: flex; align-items: center; gap: 12px; flex: 1; min-width: 250px; }
            .search-input-group { position: relative; flex: 1; }
            .search-box { width: 100%; padding: 10px 36px 10px 14px; border-radius: 10px; border: 1px solid var(--surface1); background: var(--surface); color: var(--text); outline: none; font-size: 13px; transition: all 0.2s; }
            .search-box:focus { border-color: var(--accent); box-shadow: 0 0 0 2px rgba(23,146,153,0.15); }
            .toolbar-actions { display: flex; gap: 8px; justify-content: flex-end; }

            /* Upload */
            .upload-zone { border: 2px dashed var(--surface1); border-radius: 10px; padding: 20px 16px; text-align: center; margin-bottom: 16px; transition: all 0.2s; background: var(--mantle); }
            .upload-zone.dragover { border-color: var(--accent); background: rgba(148,226,213,0.06); }
            .upload-actions { display: flex; justify-content: center; gap: 10px; flex-wrap: wrap; }
            .upload-hint { color: var(--overlay); margin-top: 10px; font-size: 12px; }
            #upload-progress { width: 100%; height: 4px; background: var(--surface1); border-radius: 2px; overflow: hidden; margin-top: 12px; display: none; }
            #upload-bar { width: 0%; height: 100%; background: var(--accent); transition: width 0.15s; border-radius: 2px; }

            /* Table */
            .table-responsive { overflow-x: auto; border-radius: 10px; border: 1px solid var(--surface1); }
            table { width: 100%; border-collapse: collapse; font-size: 13px; }
            th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--surface1); }
            th { background: var(--mantle); font-weight: 600; cursor: pointer; white-space: nowrap; color: var(--subtext); font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em; position: sticky; top: 0; z-index: 1; }
            tr.row-file:hover td { background: var(--surface); }
            td a { color: var(--text); text-decoration: none; font-weight: 500; display: flex; align-items: center; gap: 6px; }
            td a:hover { color: var(--accent); }
            .act-btn { background: none; border: none; color: var(--subtext); cursor: pointer; padding: 4px 6px; border-radius: 4px; font-size: 13px; transition: 0.15s; }
            .act-btn:hover { background: var(--surface1); color: var(--text); }
            .act-btn.del:hover { color: var(--red); }

            /* Clipboard */
            .clipboard-area { margin-top: 20px; padding-top: 16px; border-top: 1px solid var(--surface1); }
            .clipboard-area h3 { font-size: 13px; font-weight: 600; color: var(--subtext); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.04em; }
            .clipboard-area textarea { width: 100%; height: 80px; padding: 10px; border-radius: 8px; background: var(--mantle); color: var(--text); border: 1px solid var(--surface1); font-family: 'SF Mono', 'Fira Code', monospace; font-size: 13px; resize: vertical; outline: none; transition: border 0.15s; }
            .clipboard-area textarea:focus { border-color: var(--accent); }

            /* Dialog & Centering */
            dialog { background: var(--surface); color: var(--text); border: 1px solid var(--surface1); border-radius: 18px; padding: 24px; max-width: 600px; width: 90vw; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); border: none; box-shadow: 0 24px 64px rgba(0,0,0,0.5); margin: 0; }
            dialog::backdrop { background: var(--modal-bg); backdrop-filter: blur(8px); }
            dialog h3 { font-size: 18px; margin-bottom: 20px; font-weight: 600; color: var(--text); }
            dialog img { max-width: 100%; max-height: 70vh; object-fit: contain; border-radius: 12px; display: block; margin: 0 auto; box-shadow: 0 8px 32px rgba(0,0,0,0.2); }
            dialog pre { max-height: 70vh; overflow: auto; background: var(--mantle); padding: 18px; border-radius: 12px; white-space: pre-wrap; font-family: 'SF Mono', monospace; font-size: 13px; }
            dialog video { max-width: 100%; max-height: 70vh; border-radius: 12px; display: block; margin: 0 auto; outline: none; }
            .close-btn { position: absolute; top: 16px; right: 16px; background: var(--surface1); color: var(--subtext); border: none; border-radius: 50%; width: 32px; height: 32px; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 18px; transition: 0.2s; z-index: 10; }
            .close-btn:hover { background: var(--red); color: white; transform: rotate(90deg); }

            /* Disconnect overlay - full width banner */
            #disconnect-overlay { position: fixed; top: 0; left: 0; right: 0; background: var(--red); color: var(--bg); padding: 14px 20px; display: none; font-weight: 600; font-size: 15px; text-align: center; box-shadow: 0 4px 20px rgba(0,0,0,0.3); z-index: 9999; animation: slideDown 0.25s; letter-spacing: 0.02em; }
            @keyframes slideDown { from { transform: translateY(-100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

            /* Stats Gauge */
            .stats-bar { margin-top: 20px; padding: 12px; background: var(--mantle); border-radius: 10px; border: 1px solid var(--surface1); display: flex; align-items: center; gap: 15px; }
            .stats-info { font-size: 11px; color: var(--subtext); font-weight: 600; text-transform: uppercase; white-space: nowrap; }
            .gauge-wrap { flex-grow: 1; height: 6px; background: var(--surface1); border-radius: 3px; overflow: hidden; }
            .gauge-fill { height: 100%; background: var(--accent); transition: width 0.5s; }

            /* Mini QR Modal */
            #miniQR { text-align: center; }
            .qr-header-img { background: white; padding: 8px; border-radius: 8px; display: inline-block; margin-bottom: 15px; }
            
            /* Footer */
            .footer { text-align: center; padding: 16px 0 4px; color: var(--overlay); font-size: 11px; letter-spacing: 0.03em; }

            /* Mobile */
            @media (max-width: 640px) {
                body { padding: 6px; }
                .container { padding: 14px; border-radius: 10px; }
                .header { flex-direction: column; align-items: flex-start; gap: 8px; }
                h2.breadcrumb { font-size: 14px; }
                .toolbar { flex-direction: column; align-items: stretch; }
                .search-wrap { max-width: 100%; }
                .toolbar-actions { justify-content: flex-start; }
                .upload-zone { padding: 16px 12px; }
                th, td { padding: 8px 6px; font-size: 12px; }
                .btn { padding: 7px 12px; font-size: 12px; }
                .clipboard-area textarea { height: 64px; font-size: 12px; }
            }
        """)
        r.append("</style>")
        
        # JAVASCRIPT LOGIC
        r.append("<script>")
        r.append("""
            // Clean credentials from URL to prevent fetch API errors
            if (window.location.href.includes('@')) {
                window.history.replaceState({}, document.title, window.location.protocol + '//' + window.location.host + window.location.pathname + window.location.search);
            }
            
            function getAuthHeader() { return 'Basic ' + btoa('bockshare:' + document.getElementById('serverAuthPin').value); }
            
            async function apiRequest(endpoint, payload) {
                try {
                    let res = await fetch(window.location.origin + endpoint, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': getAuthHeader()
                        },
                        body: JSON.stringify(payload)
                    });
                    let data = await res.json();
                    if (!res.ok) throw new Error(data.error || 'Server error');
                    return data;
                } catch(e) {
                    alert('Action failed: ' + e.message);
                    throw e;
                }
            }

            async function shutdownServer() {
                if(!confirm("Shut down the cloud server? All active downloads will be interrupted.")) return;
                try {
                    await apiRequest('/api/shutdown', {});
                    document.body.innerHTML = '<h1 style="color:var(--accent); text-align:center; padding-top:100px;">☁️ Server stopped. You can close this tab.</h1>';
                } catch(e) {}
            }

            async function createFolder() {
                let name = prompt("New folder name:");
                if(!name || name.trim()==='') return;
                try {
                    let data = await apiRequest('/api/mkdir', { pwd: document.getElementById('pwd').value, target: name });
                    renderTable(data.files);
                } catch(e) {}
            }

            async function renameItem(oldName) {
                let newName = prompt(`Rename '${oldName}':`, oldName);
                if(!newName || newName === oldName) return;
                try {
                    let data = await apiRequest('/api/rename', { pwd: document.getElementById('pwd').value, old: oldName, new: newName });
                    renderTable(data.files);
                } catch(e) {}
            }

            async function deleteItem(name, isDir) {
                let msg = isDir ? `Permanently delete folder '${name}' and all contents?` : `Permanently delete '${name}'?`;
                if(!confirm(msg)) return;
                try {
                    let data = await apiRequest('/api/delete', { pwd: document.getElementById('pwd').value, targets: [name] });
                    renderTable(data.files);
                } catch(e) {}
            }

            async function bulkDelete() {
                let cbs = document.querySelectorAll('.file-cb:checked');
                if(cbs.length === 0) return alert('Select at least one item using the checkboxes.');
                if(!confirm(`Permanently delete ${cbs.length} selected item(s)?`)) return;
                
                let targets = Array.from(cbs).map(cb => decodeURIComponent(cb.value));
                try {
                    let data = await apiRequest('/api/delete', { pwd: document.getElementById('pwd').value, targets: targets });
                    renderTable(data.files);
                } catch(e) {}
            }

            async function fetchStats() {
                try {
                    let r = await fetch('/api/stats', { headers: { 'Authorization': getAuthHeader() } });
                    let d = await r.json();
                    let storageLabel = 'Storage';
                    if (navigator.platform.indexOf('Mac') > -1) storageLabel = 'Mac Storage';
                    else if (navigator.userAgent.indexOf('Android') > -1) storageLabel = 'Phone Storage';
                    document.getElementById('gauge-fill').style.width = d.used_pct + '%';
                    document.getElementById('stats-text').innerText = `${storageLabel}: ${d.used_pct}% Full | ${d.free_gb} GB Free`;
                } catch(e) {}
            }

            async function globalSearch() {
                let q = document.getElementById('searchInput').value;
                if (q.length < 1) { refreshDir(); return; }

                try {
                    let r = await fetch(`/api/search?q=${encodeURIComponent(q)}&recursive=true`, { headers: { 'Authorization': getAuthHeader() } });
                    let d = await r.json();
                    renderTable(d.results, true);
                } catch(e) {}
            }

            async function refreshDir() {
                try {
                    let pwd = document.getElementById('pwd').value;
                    let r = await fetch(`/api/list?pwd=${encodeURIComponent(pwd)}`, { headers: { 'Authorization': getAuthHeader() } });
                    let d = await r.json();
                    renderTable(d.files);
                } catch(e) {}
            }

            function renderTable(files, isSearch = false) {
                let tbody = document.querySelector('#fileTable tbody');
                let rows = Array.from(tbody.querySelectorAll('tr'));
                let header = rows[0];
                let backRow = rows.find(r => r.classList.contains('row-parent'));
                
                tbody.innerHTML = '';
                tbody.appendChild(header);
                if (backRow && !isSearch) tbody.appendChild(backRow);

                if (files.length === 0) {
                    let tr = document.createElement('tr');
                    tr.innerHTML = `<td colspan="5" style="text-align:center; padding: 40px; color: var(--overlay);">No matching files found.</td>`;
                    tbody.appendChild(tr);
                    return;
                }

                files.forEach(f => {
                    let tr = document.createElement('tr');
                    tr.className = 'row-file';
                    let safeName = f.name.replace(/'/g, "&apos;");
                    let link = encodeURIComponent(f.name) + (f.is_dir ? "/" : "");
                    let tagAttr = f.is_dir ? "" : "download";
                    let preview = "";
                    let ext = f.name.split('.').pop().toLowerCase();
                    if (!f.is_dir) {
                        if (['jpg','jpeg','png','gif','webp'].includes(ext)) preview = `onclick='event.preventDefault(); openPreview("${encodeURIComponent(f.name)}", "img")'`;
                        else if (['mp4','webm','mov'].includes(ext)) preview = `onclick='event.preventDefault(); openPreview("${encodeURIComponent(f.name)}", "video")'`;
                        else if (['mp3','wav','ogg','m4a','flac','aac'].includes(ext)) preview = `onclick='event.preventDefault(); openPreview("${encodeURIComponent(f.name)}", "audio")'`;
                        else if (['pdf'].includes(ext)) preview = `onclick='event.preventDefault(); openPreview("${encodeURIComponent(f.name)}", "pdf")'`;
                        else if (['txt','md','py','json','csv','log','html','css','js'].includes(ext)) preview = `onclick='event.preventDefault(); openPreview("${encodeURIComponent(f.name)}", "text")'`;
                    }

                    tr.innerHTML = `
                        <td><input type="checkbox" class="file-cb" name="files" value="${encodeURIComponent(f.name)}"></td>
                        <td><a href="${link}" ${tagAttr} ${preview}>${f.is_dir ? '📂' : '📄'} ${f.path}</a></td>
                        <td>${f.size}</td>
                        <td>${f.mtime}</td>
                        <td style="text-align:right">
                            <button type="button" class="act-btn" onclick="renameItem('${safeName}')" title="Rename">✏️</button>
                            <button type="button" class="act-btn del" onclick="deleteItem('${safeName}', ${f.is_dir})" title="Delete">🗑️</button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            }

            function toggleMiniQR() {
                let d = document.getElementById('qrDialog');
                if (d.showModal) d.showModal(); else d.open = true;
            }
            
            // Close modals on click-outside (backdrop)
            document.addEventListener('click', (e) => {
                if (e.target.tagName === 'DIALOG') e.target.close();
            });

            // Clipboard Logic
            let clipTimer;
            async function pollClipboard() {
                try {
                    let r = await fetch(window.location.origin + '/api/clipboard?_t=' + Date.now(), { headers: { 'Authorization': getAuthHeader() } });
                    if(r.ok) {
                        let data = await r.json();
                        let box = document.getElementById('clipBox');
                        if (data.text !== box.value && document.activeElement !== box) {
                            box.value = data.text;
                        }
                        document.getElementById('disconnect-overlay').style.display = 'none';
                    } else if(r.status === 401) {
                        location.reload(); // Re-trigger auth
                    } else {
                        document.getElementById('disconnect-overlay').style.display = 'block';
                    }
                } catch(e) {
                    document.getElementById('disconnect-overlay').style.display = 'block';
                }
            }
            
            function pushClipboard() {
                clearTimeout(clipTimer);
                clipTimer = setTimeout(() => {
                    apiRequest('/api/clipboard', { text: document.getElementById('clipBox').value }).catch(()=>{});
                }, 400); // Debounce to prevent heavy api flooding
            }

            // Uploader
            async function uploadFiles(files) {
                if(files.length === 0) return;
                document.getElementById('upload-progress').style.display = 'block';
                let totalBytes = Array.from(files).reduce((acc, f) => acc + f.size, 0);
                let loadedBytes = 0;
                
                for (let file of files) {
                    let relPath = file.webkitRelativePath || file.name;
                    try {
                        await fetch(window.location.origin + '/api/upload', {
                            method: 'POST',
                            headers: { 
                                'X-File-Name': encodeURIComponent(relPath), 
                                'X-Pwd': encodeURIComponent(document.getElementById('pwd').value),
                                'Authorization': getAuthHeader()
                            },
                            body: file
                        });
                    } catch(e) { console.error("Upload fail: " + relPath); }
                    
                    loadedBytes += file.size;
                    document.getElementById('upload-bar').style.width = Math.min((loadedBytes/totalBytes)*100, 100) + '%';
                }
                
                setTimeout(() => {
                    apiRequest('/api/notify', { count: files.length }).finally(() => location.reload());
                }, 500);
            }

            // Drag/Drop Setup
            function setupPage() {
                const z = document.getElementById('drop-zone');
                z.addEventListener('dragover', (e) => { e.preventDefault(); z.classList.add('dragover'); });
                z.addEventListener('dragleave', (e) => { e.preventDefault(); z.classList.remove('dragover'); });
                z.addEventListener('drop', (e) => { e.preventDefault(); z.classList.remove('dragover'); uploadFiles(e.dataTransfer.files); });
                document.getElementById('fileInput').addEventListener('change', (e) => uploadFiles(e.target.files));
                document.getElementById('folderInput').addEventListener('change', (e) => uploadFiles(e.target.files));
                
                // Light/Dark Config
                let saved = localStorage.getItem('serve-theme') || 'dark';
                document.documentElement.setAttribute('data-theme', saved);
                document.getElementById('themeBtn').innerHTML = saved === 'dark' ? ICON_SUN : ICON_MOON;
                
                // Start Polling
                pollClipboard();
                setInterval(pollClipboard, 1500);
                fetchStats();
            }

            function toggleTheme() {
                let current = document.documentElement.getAttribute('data-theme');
                let next = current === 'dark' ? 'light' : 'dark';
                document.documentElement.setAttribute('data-theme', next);
                localStorage.setItem('serve-theme', next);
                document.getElementById('themeBtn').innerHTML = next === 'dark' ? ICON_SUN : ICON_MOON;
            }

            // Lightbox
            function openPreview(url, type) {
                const diag = document.getElementById('previewDialog');
                const content = document.getElementById('previewContent');
                content.innerHTML = '';
                if(type === 'img') content.innerHTML = `<img src="${url}" style="max-height:80vh; max-width:100%; border-radius:8px;">`;
                else if(type === 'video') content.innerHTML = `<video controls autoplay src="${url}" style="max-width:100%; max-height:80vh; border-radius:8px;"></video>`;
                else if(type === 'audio') content.innerHTML = `
                    <div style="padding:40px 20px; text-align:center;">
                        <div style="font-size:48px; margin-bottom:20px;">🎵</div>
                        <audio controls autoplay src="${url}" style="width:100%; max-width:400px;"></audio>
                        <p style="margin-top:20px; color:var(--subtext); font-size:13px;">${decodeURIComponent(url.split('/').pop())}</p>
                    </div>`;
                else if(type === 'pdf') content.innerHTML = `<iframe src="${url}" style="width:100%; height:80vh; border:none; border-radius:8px;"></iframe>`;
                else if(type === 'text') {
                    fetch(url).then(r=>r.text()).then(t => { content.innerHTML = `<pre style="max-height:80vh; overflow:auto; text-align:left; background:var(--mantle); padding:20px; border-radius:8px; font-size:13px; color:var(--text);">${t.replace(/</g, "&lt;")}</pre>`; });
                }
                diag.showModal();
            }

            // Sort & Search
            let sortCols = [1, 1, 1, 1];
            function sortTable(n, type) {
                let table = document.getElementById("fileTable");
                let rows = Array.from(table.rows).slice(1).filter(r => !r.classList.contains('row-parent'));
                let parentRow = Array.from(table.rows).slice(1).find(r => r.classList.contains('row-parent'));
                
                let dir = sortCols[n] === 1 ? 1 : -1;
                sortCols[n] *= -1;
                
                rows.sort((a,b) => {
                    let v1 = a.cells[n].innerText.trim();
                    let v2 = b.cells[n].innerText.trim();
                    if(type === 'str') return v1.localeCompare(v2) * dir;
                    if(type === 'size') {
                        let parseSize = s => {
                            let match = s.match(/([0-9.]+)\\s*([A-Z]+)/i);
                            if(!match) return 0;
                            let units = {B:1, KB:1024, MB:1024*1024, GB:1024*1024*1024};
                            return parseFloat(match[1]) * (units[match[2].toUpperCase()] || 1);
                        };
                        return (parseSize(v1) - parseSize(v2)) * dir;
                    }
                    if(type === 'date') return ((new Date(v1).getTime()||0) - (new Date(v2).getTime()||0)) * dir;
                    return 0;
                });
                if(parentRow) table.querySelector('tbody').appendChild(parentRow);
                rows.forEach(r => table.querySelector('tbody').appendChild(r));
            }
            
            function searchTable() {
                let term = document.getElementById('searchInput').value.toLowerCase();
                // Always use global (recursive) search now
                globalSearch();
                document.getElementById('searchClear').style.display = term === '' ? 'none' : 'inline-block';
            }
            function resetSearch() { document.getElementById('searchInput').value = ''; searchTable(); }

            function downloadSelected() {
                let cbs = document.querySelectorAll('.file-cb:checked');
                if(cbs.length === 0) return alert('Select at least one file to download.');
                document.getElementById('downloadForm').submit();
            }
        """)
        r.append("</script></head><body onload='setupPage()'>")
        
        # Disconnect Overlay & Dialogs
        r.append("<div id='disconnect-overlay'>Server connection lost — reconnecting...</div>")
        r.append("<dialog id='previewDialog'><button class='close-btn' onclick='this.parentElement.close();'>×</button><div id='previewContent'></div></dialog>")
        
        protocol_str = 'https' if USE_HTTPS else 'http'
        qr_url = f"{protocol_str}://{get_ip()}:{PORT}/__login__?pin={AUTH_PIN}"
        qr_img = f"https://api.qrserver.com/v1/create-qr-code/?size=160x160&data={urllib.parse.quote(qr_url)}&margin=0"
        r.append(f"<dialog id='qrDialog'><button class='close-btn' onclick='this.parentElement.close()'>×</button><div id='miniQR'><h3>Auto-Login QR</h3><div class='qr-header-img'><img src='{qr_img}'></div><p style='font-size:11px; color:var(--subtext);'>Scan to connect another device</p></div></dialog>")

        # Breadcrumb setup
        is_root = (displaypath == '/')
        # Use only the logo image as the root link (cleaner look)
        logo_img = f"<img src='data:image/png;base64,{FAVICON_B64}' class='root-logo-img' title='Home'>"
        brand_html = f"<div class='brand-logo'>{logo_img}</div>"
        breadcrumb = brand_html if is_root else f"<a href='/' style='border:none; background:none; padding:0;'>{brand_html}</a>"
        if not is_root:
            parts = [p for p in displaypath.split('/') if p]
            curr_acc = ""
            for p in parts:
                curr_acc += f"/{p}"
                breadcrumb += f"<span>/</span><a href='{urllib.parse.quote(curr_acc)}/'>{html.escape(p)}</a>"

        # SVG Icons
        ICON_QR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="5" height="5" x="3" y="3" rx="1"/><rect width="5" height="5" x="16" y="3" rx="1"/><rect width="5" height="5" x="3" y="16" rx="1"/><path d="M21 16h-3a2 2 0 0 0-2 2v3"/><path d="M21 21v.01"/><path d="M12 7v3a2 2 0 0 1-2 2H7"/><path d="M3 12h.01"/><path d="M12 3h.01"/><path d="M12 16v.01"/><path d="M16 12h1"/><path d="M21 12v.01"/><path d="M12 21v-1"/></svg>'
        ICON_SUN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="M4.93 4.93l1.41 1.41"/><path d="M17.66 17.66l1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="M4.93 19.07l1.41-1.41"/><path d="M17.66 6.34l1.41-1.41"/></svg>'
        ICON_MOON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>'
        ICON_POWER = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v10"/><path d="M18.36 6.64a9 9 0 1 1-12.72 0"/></svg>'
        ICON_TRASH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>'
        ICON_FOLDER = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"/></svg>'
        ICON_DL = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="3" y2="15"/></svg>'

        # JS Config for Theme Button
        js_theme_icon = f"const ICON_SUN=`{ICON_SUN}`; const ICON_MOON=`{ICON_MOON}`;"
        r.append(f"<script>{js_theme_icon}</script>")

        r.append("<div class='container'>")
        
        # Header: App name + Breadcrumb + system controls
        r.append("<div class='header'>")
        r.append(f"<h2 class='breadcrumb'>{breadcrumb}</h2>")
        r.append("<div class='sys-controls'>")
        r.append(f"<button id='themeBtn' class='btn btn-ghost btn-sm theme-btn-fixed' onclick='toggleTheme()' title='Toggle Theme'></button>")
        r.append(f"<button class='btn btn-ghost btn-sm btn-icon-only' onclick='toggleMiniQR()' title='Show QR Network Code'>{ICON_QR}</button>")
        r.append(f"<button class='btn btn-ghost btn-sm btn-danger btn-icon-only' onclick='shutdownServer()' title='Quit'>{ICON_POWER}</button>")
        r.append("</div></div>")

        # Upload Zone (Row 1)
        r.append("<div class='upload-zone layout-row' id='drop-zone'>")
        r.append("<div class='upload-actions'>")
        r.append("<button class='btn' onclick='document.getElementById(\"fileInput\").click()'>Upload Files</button>")
        r.append("<button class='btn btn-ghost' onclick='document.getElementById(\"folderInput\").click()'>Upload Folder</button>")
        r.append("</div>")
        r.append("<p class='upload-hint'>or drag & drop here</p>")
        r.append("<input type='file' id='fileInput' multiple style='display:none;'><input type='file' id='folderInput' webkitdirectory directory multiple style='display:none;'>")
        r.append(f"<input type='hidden' id='serverAuthPin' value='{AUTH_PIN}'>")
        r.append(f"<input type='hidden' id='pwd' value='{html.escape(displaypath)}'>")
        r.append("<div id='upload-progress'><div id='upload-bar'></div></div>")
        r.append("</div>")

        # Search Toolbar (ABOVE Clipboard)
        r.append("<div class='toolbar layout-row' style='margin-bottom:16px;'>")
        r.append("<div class='search-wrap'>")
        r.append("<div class='search-input-group'>")
        r.append("<input type='text' id='searchInput' class='search-box' placeholder='Search all folders...' onkeyup='searchTable()'>")
        r.append("<span id='searchClear' onclick='resetSearch()' style='position:absolute; right:12px; top:10px; cursor:pointer; display:none; color:var(--overlay);'>×</span>")
        r.append("</div>")
        r.append("</div></div>")

        # Clipboard (Shared Row)
        r.append("<div class='clipboard-area layout-row' style='margin-bottom:16px;'>")
        r.append("<h3>Shared Clipboard</h3>")
        r.append("<textarea id='clipBox' oninput='pushClipboard()' placeholder='Syncs across devices in real time...'></textarea>")
        r.append("</div>")

        # Action Toolbar (BELOW Clipboard)
        r.append("<div class='action-toolbar layout-row'>")
        r.append("<div class='toolbar-actions' style='width:100%; display:flex; justify-content:space-between;'>")
        r.append("<div style='display:flex; gap:8px;'>")
        r.append(f"<button class='btn btn-ghost btn-sm' onclick='createFolder()' title='New Folder'>{ICON_FOLDER} New</button>")
        r.append(f"<button type='button' class='btn btn-ghost btn-sm' onclick='downloadSelected()' title='Download Selected'>{ICON_DL} Download</button>")
        r.append("</div>")
        r.append(f"<button class='btn btn-ghost btn-sm btn-danger' onclick='bulkDelete()' title='Delete Selected'>{ICON_TRASH} Delete</button>")
        r.append("</div></div>")

        # Table Form for Zip
        r.append("<form method='POST' action='/api/zip_download' id='downloadForm' target='_blank'>")
        r.append(f"<input type='hidden' name='pwd' value='{urllib.parse.quote(displaypath)}'>")
        r.append("<div class='table-responsive'><table id='fileTable'>")
        r.append("<tr><th><input type='checkbox' onclick=\"document.querySelectorAll('.file-cb').forEach(cb => cb.checked = this.checked)\"></th>")
        r.append("<th style='cursor:pointer;' onclick='sortTable(1, \"str\")'>Name ↕</th>")
        r.append("<th style='cursor:pointer;' onclick='sortTable(2, \"size\")'>Size ↕</th>")
        r.append("<th style='cursor:pointer;' onclick='sortTable(3, \"date\")'>Modified ↕</th>")
        r.append("<th>Actions</th></tr>")
        
        if displaypath != '/':
            r.append("<tr class='row-parent'><td></td><td><a href='../'>.. Back</a></td><td></td><td></td><td></td></tr>")
        
        for name in list_dir:
            if name.startswith('.'): continue
            fullname = os.path.join(path, name)
            is_dir = os.path.isdir(fullname)
            
            ext = os.path.splitext(name)[1].lower()
            preview_js = ""
            if not is_dir:
                if ext in ['.jpg','.jpeg','.png','.gif','.webp']: preview_js = f"onclick='event.preventDefault(); openPreview(\"{urllib.parse.quote(name)}\", \"img\")'"
                elif ext in ['.mp4','.webm','.mov']: preview_js = f"onclick='event.preventDefault(); openPreview(\"{urllib.parse.quote(name)}\", \"video\")'"
                elif ext in ['.txt','.md','.py','.json','.csv','.log']: preview_js = f"onclick='event.preventDefault(); openPreview(\"{urllib.parse.quote(name)}\", \"text\")'"
            
            link = urllib.parse.quote(name) + ("/" if is_dir else "")
            tag_attr = "" if is_dir else "download"
            displayname = f"{'📂' if is_dir else '📄'} {html.escape(name)}"
            href_link = f"<a href='{link}' {tag_attr} {preview_js}>{displayname}</a>"
            
            try:
                st = os.stat(fullname)
                sz = self.format_size(st.st_size) if not is_dir else "-"
                mt = datetime.datetime.fromtimestamp(st.st_mtime).strftime('%Y-%m-%d %H:%M')
            except: sz, mt = "-", "-"

            name_val = urllib.parse.quote(name)
            safe_name = html.escape(name).replace('"', '&quot;')

            r.append(f"<tr class='row-file'><td><input type='checkbox' class='file-cb' name='files' value='{name_val}'></td>")
            r.append(f"<td>{href_link}</td>")
            r.append(f"<td>{sz}</td><td>{mt}</td>")
            r.append(f"<td style='text-align:right'><button type='button' class='act-btn' onclick='renameItem(\"{safe_name}\")' title='Rename'>✏️</button>")
            r.append(f"<button type='button' class='act-btn del' onclick='deleteItem(\"{safe_name}\", {'true' if is_dir else 'false'})' title='Delete'>🗑️</button></td></tr>")
        
        r.append("</table></div></form>")

        # Table Footer: Stats
        r.append("<div class='stats-bar'>")
        r.append("<div class='stats-info' id='stats-text'>Mac Storage: Calculating...</div>")
        r.append("<div class='gauge-wrap'><div class='gauge-fill' id='gauge-fill' style='width:0%'></div></div>")
        r.append("</div>")

        # Footer
        r.append("<div class='footer'>BOCKshare &middot; &copy; " + str(datetime.datetime.now().year) + " David Tobias Bock</div>")
        
        r.append("</div></body></html>")
        
        encoded = '\n'.join(r).encode('utf-8')
        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        return io.BytesIO(encoded)

    def serve_landing(self):
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.end_headers()
        protocol_str = 'https' if USE_HTTPS else 'http'
        auto_login = f"{protocol_str}://{get_ip()}:{PORT}/__login__?pin={AUTH_PIN}"
        html_code = f"""<!DOCTYPE html>
<html data-theme='dark'>
<head>
    <title>BOCKshare Dashboard</title>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <style>
        :root {{ --bg:#1e1e2e; --mantle:#181825; --surface:#313244; --surface1:#45475a; --text:#cdd6f4; --subtext:#a6adc8; --accent:#94e2d5; }}
        * {{ box-sizing: border-box; margin: 0; }}
        body {{ background: var(--bg); color: var(--text); font-family: -apple-system, BlinkMacSystemFont, 'Inter', sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; padding: 20px; text-align:center; }}
        .card {{ background: var(--surface); padding: 40px; border-radius: 16px; text-align: center; box-shadow: 0 8px 32px rgba(0,0,0,0.4); max-width: 420px; width: 100%; }}
        .qr-box {{ background: white; padding: 14px; border-radius: 12px; display: inline-block; margin: 20px 0; }}
        .btn {{ background: var(--accent); color: var(--bg); padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 14px; display: inline-block; transition: all 0.15s; border: none; cursor: pointer; }}
        .btn:hover {{ filter: brightness(1.1); transform: translateY(-1px); }}
        .cred {{ background: var(--mantle); padding: 8px 14px; border-radius: 6px; font-family: 'SF Mono', monospace; display: inline-block; margin-bottom: 5px; color: var(--accent); font-size: 14px; }}
        .footer {{ margin-top: 24px; color: var(--subtext); font-size: 11px; letter-spacing: 0.03em; }}
    </style>
</head>
<body>
    <div class='card'>
        <h2 style='margin-top: 0; font-size: 24px; font-weight: 700;'>BOCKshare</h2>
        <div style='margin-top:20px;'>
            <div class='cred'>User: bockshare</div><br>
            <div class='cred'>PIN: {AUTH_PIN}</div>
        </div>
        <div class='qr-box'>
            <img id='qr-img' src='https://api.qrserver.com/v1/create-qr-code/?size=200x200&data={urllib.parse.quote(auto_login)}&margin=0' alt='Auto-Login'>
        </div>
        <p style='color:var(--subtext); font-size:13px; margin-bottom: 12px;'>Scan with your phone for <b style="color:var(--accent)">Auto-Login</b></p>
        
        <div style='margin-bottom: 24px; display: flex; align-items: center; justify-content: center; gap: 8px;'>
            <input type='checkbox' id='debug-tick' style='width:16px; height:16px; cursor:pointer;'>
            <label for='debug-tick' style='font-size:13px; color:var(--text); cursor:pointer;'>Enable Session Log</label>
        </div>

        <a href='/' id='enter-btn' class='btn'>Enter Cloud</a>
    </div>
    <div class='footer'>&copy; {datetime.datetime.now().year} David Tobias Bock</div>
    <script>
        const AUTH_BASE = "{auto_login}";
        const qrImg = document.getElementById('qr-img');
        const enterBtn = document.getElementById('enter-btn');
        const debugTick = document.getElementById('debug-tick');

        function updateContext() {{
            let isDebug = debugTick.checked;
            let finalUrl = AUTH_BASE + (isDebug ? "&debug=1" : "");
            qrImg.src = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&margin=0&data=" + encodeURIComponent(finalUrl);
            enterBtn.href = "/__login__?pin={AUTH_PIN}" + (isDebug ? "&debug=1" : "");
        }}
        
        debugTick.addEventListener('change', updateContext);
        updateContext(); // Init

        setInterval(async () => {{
            try {{
                let r = await fetch(window.location.origin + '/api/check_mobile');
                let d = await r.json();
                if(d.status === 'OK') window.location.href = enterBtn.href;
            }} catch(e) {{}}
        }}, 1000);
    </script>
</body>
</html>"""
        self.wfile.write(html_code.encode('utf-8'))

if __name__ == '__main__':
    class DualStackServer(socketserver.ThreadingTCPServer): allow_reuse_address = True
    
    if len(sys.argv) <= 1 or (len(sys.argv) > 1 and sys.argv[1].isdigit()):
        if len(sys.argv) > 1 and os.path.isdir(sys.argv[-1]):
            pass 
        else:
            debug_log("📁 Prompting for folder...")
            sel_path = select_folder()
            if sel_path:
                os.chdir(sel_path)
                debug_log(f"✅ Folder selected: {sel_path}")
            else:
                debug_log("❌ Cancelled folder picker.")
                sys.exit(0)

    # Port Auto-Selection
    port_attempt = PORT
    for _ in range(10): 
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(('0.0.0.0', port_attempt))
                PORT = port_attempt
                debug_log(f"🔌 Port check: {PORT} is available.")
                break
        except:
            debug_log(f"⚠️ Port {port_attempt} is busy, trying next...")
            port_attempt += 1

    if '--build' in sys.argv:
        is_win = platform.system() == "Windows"
        desktop = os.path.expanduser('~/Desktop')
        out_ext = '.bat' if is_win else '.command'
        out_cmd = os.path.join(desktop, f'BOCKshare{out_ext}')
        icon_src = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bs_icon.png')
        
        # Binary build check
        cmd = None
        nuitka_check = "where nuitka" if is_win else "command -v nuitka"
        if subprocess.call(f"{nuitka_check} >nul 2>&1", shell=True) == 0:
            print("🚀 Nuitka found! Building optimized binary...")
            args = ['nuitka', '--onefile', '--output-dir=' + desktop, __file__]
            if not is_win: args += ['--macos-create-app-bundle', '--macos-app-icon=' + icon_src if os.path.exists(icon_src) else '']
            subprocess.run(args)
            sys.exit(0)

        # PyInstaller fallback
        pyi_check = "where pyinstaller" if is_win else "command -v pyinstaller"
        if subprocess.call(f"{pyi_check} >nul 2>&1", shell=True) == 0:
            print("🚀 PyInstaller found! Creating standalone build...")
            pyi_args = ['pyinstaller', '--onefile', '--windowed', '--noconfirm', '--name=BOCKshare', '--distpath=' + desktop]
            if os.path.exists(icon_src): pyi_args += ['--icon=' + icon_src]
            pyi_args.append(__file__)
            subprocess.run(pyi_args)
            sys.exit(0)

        # Portable script fallback
        with open(__file__, 'rb') as f: b64 = base64.b64encode(f.read()).decode('utf-8')
        if is_win:
            sh = f'@echo off\nset /p TARGET="Folder to share: "\ncd /d "%TARGET%"\necho {b64} > b.b64\ncertutil -decode b.b64 b.py\npython b.py %PORT% "%TARGET%"\ndel b.b64 b.py'
        else:
            sh = f'#!/bin/bash\nTARGET=$(osascript -e "POSIX path of (choose folder)")\ncd "$TARGET"\necho "{b64}" | base64 -D > b.py\npython3 b.py "$PORT" "$TARGET"\nrm b.py'
        with open(out_cmd, 'w') as f: f.write(sh)
        os.chmod(out_cmd, 0o755)
        print(f"✅ Portable script created: {out_cmd}")
        sys.exit(0)

    try:
        with DualStackServer(("0.0.0.0", PORT), EnhancedHTTPRequestHandler) as httpd:
            protocol, local_ip = "http", get_ip()
            if USE_HTTPS:
                cf = gen_cert(local_ip)
                if cf:
                    c = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                    c.load_cert_chain(certfile=cf)
                    httpd.socket = c.wrap_socket(httpd.socket, server_side=True)
                    protocol = "https"
            
            ascii_lines = [
                r"  ____   ___   ____ _  __     _                        ",
                r" | __ ) / _ \ / ___| |/ /___ | |__   __ _ _ __ ___ ",
                r" |  _ \| | | | |   | ' // __|| '_ \ / _` | '__/ _ \ ",
                r" | |_) | |_| | |___| . \\__ \| | | | (_| | | |  __/",
                r" |____/ \___/ \____|_|\_\___/|_| |_|\__,_|_|  \___|"
            ]
            print("\x1b[38;2;161;239;211m\n" + "\n".join(ascii_lines))
            print("\x1b[38;2;135;223;235m\n (c) 2026 David Tobias Bock • BOCKshare 4.2 Cloud\x1b[0m\n")
            print(f"👤 User: \x1b[1;36mbockshare\x1b[0m ☁️")
            print(f"🔒 PIN:             \x1b[1;32m{AUTH_PIN}\x1b[0m")
            if IS_IPAD: system_label = "iPad"
            elif IS_ANDROID: system_label = "Android"
            else: system_label = "Mac" if platform.system() == "Darwin" else "Windows"
            print(f"🖥️ {system_label} Auto-Login:  \x1b[4;34m{protocol}://localhost:{PORT}/__login__?pin={AUTH_PIN}\x1b[0m")
            print(f"📱 Handy Browser:   {protocol}://{local_ip}:{PORT}/__login__?pin={AUTH_PIN}")
            
            auth_url = f"{protocol}://{local_ip}:{PORT}/__login__?pin={AUTH_PIN}"
            print(f"\n✨ QR-Scanner: (Auto-Login Magic 🪄)")
            try:
                if subprocess.call("command -v qrencode >/dev/null", shell=True) == 0: subprocess.call(["qrencode", "-t", "UTF8", auth_url])
                else: subprocess.call(["curl", "-s", f"https://qrenco.de/{auth_url}"])
            except: pass
            
            def boot_browser():
                import time, http.client
                url = f"{protocol}://localhost:{PORT}/__login__?pin={AUTH_PIN}&next=/__landing__"
                debug_log(f"🌐 Booting browser loop for {url}")
                
                # Check for server readiness
                for _ in range(20):
                    try:
                        time.sleep(0.5)
                        conn = http.client.HTTPConnection("localhost", PORT)
                        conn.request("HEAD", "/")
                        if conn.getresponse():
                            debug_log("✅ Server is up! Launching browser.")
                            open_url(url)
                            return
                    except: pass
                
                # Final fallback
                debug_log("⚠️ Readiness check timed out. Attempting fallback open.")
                subprocess.run(['open', url], check=False)

            threading.Thread(target=boot_browser, daemon=True).start()
            
            print("\n")
            httpd.serve_forever()
    except OSError as e:
        print(f"Error: Port {PORT} in use." if e.errno == 48 else e)
